import NewsAPI from 'newsapi';

export const newsApi = new NewsAPI('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');